#!/usr/bin/env python3
"""Independent saved thematic-page audit against the seven-language index and language JSONs.
Does not edit imported data. No network. Run in a directory containing data/index.json and data/{en,hr}.json.
"""
from pathlib import Path
import os
from email.parser import BytesParser
from email import policy
from bs4 import BeautifulSoup
from collections import Counter,defaultdict
from urllib.parse import urlparse
from hashlib import sha256
import csv,json,re

SOURCE_FILES={
'en/annual':'Annual Medjugorje Messages - list - Medjugorje WebSite.mht',
'en/special':'Other Medjugorje Messages - list - Medjugorje WebSite.mht',
'hr/annual':'Godišnje poruke iz Međugorja - list - Medjugorje WebSite.mht',
'hr/special':'Posebne poruke - list - Medjugorje WebSite.mht',
}
ROOT=Path(__file__).resolve().parent
SOURCE_ROOT=Path(os.environ.get('MHT_SOURCE_DIR', str(ROOT/'sources')))
OUT=Path(os.environ.get('MHT_AUDIT_OUT',str(ROOT)))
DATA=Path(os.environ.get('MHT_DATA_DIR',str(ROOT/'data')))
OUT.mkdir(parents=True,exist_ok=True)

def load_mht(path):
 m=BytesParser(policy=policy.default).parsebytes(path.read_bytes())
 parts=[x for x in m.walk() if x.get_content_type()=='text/html' and x.get_payload(decode=True)]
 if len(parts)!=1:raise RuntimeError(f'Expected one HTML part: {path.name}: {len(parts)}')
 part=parts[0]
 return BeautifulSoup(part.get_payload(decode=True),'html.parser'),part.get('Content-Location')

def normalize_node(tag):
 soup=BeautifulSoup(str(tag),'html.parser')
 for t in soup.select('script,style,noscript,span.bq,span.eq'):t.decompose()
 for t in soup.select('br'):t.replace_with('\n')
 inner=soup.find(tag.name)
 txt=inner.get_text('',strip=False).replace('\xa0',' ').replace('\u200b','')
 txt=re.sub(r'[ \t\r\f\v]+',' ',txt)
 txt='\n'.join(line.strip() for line in txt.split('\n'))
 return re.sub(r'\n{3,}','\n\n',txt).strip()

idx=json.loads((DATA/'index.json').read_text(encoding='utf8'))
indexes={x['id']:x for x in idx['messages']}
archives={lang:{x['id']:x for x in json.loads((DATA/f'{lang}.json').read_text(encoding='utf8'))['messages']} for lang in ('en','hr')}
by_category={}
violations=[]
spage=[]
all_rows=[]
links_all=[]

for key,name in SOURCE_FILES.items():
 lang,cat=key.split('/')
 path=SOURCE_ROOT/name
 soup,origin=load_mht(path)
 expected_origin=f'https://www.medjugorje.ws/{lang}/messages/{cat}/'
 if origin!=expected_origin:violations.append(dict(page=key,error='wrong_original',detail=origin))
 headings=soup.select('h2.poselstvi-datum')
 grouped=defaultdict(list)
 current_group=None
 # This walks actual source order; grouping comes from source anchor, NEVER date assumptions.
 for el in soup.find_all(['a','h2']):
  if el.name=='a' and el.get('name') and el['name'].startswith(cat+'.'):
   current_group=el.get('name').split('.',1)[1]
  elif el.name=='h2' and 'poselstvi-datum' in (el.get('class') or []):
   link=el.select_one('a[href]')
   url=link.get('href','') if link else ''
   pathfrag=urlparse(url).path
   match=re.fullmatch(rf'/{lang}/messages/(\d{{6}}[a-z][\w-]*)/?',pathfrag)
   head=el.find_parent('div',class_='mm-head')
   checkbox=head.select_one('input[type="checkbox"]') if head else None
   datesrc=checkbox.get('value','') if checkbox else ''
   dm=re.match(r'(\d{4}-\d{2}-\d{2})_',datesrc)
   if not (match and dm):
    violations.append(dict(page=key,error='unparseable_header',detail=el.get_text(' ',strip=True)[:130]));continue
   date,slug=dm.group(1),match.group(1)
   id=date[2:4]+date[5:7]+date[8:10]+slug[6:]
   title=el.get_text(' ',strip=True)
   segments=[]
   for sib in head.next_siblings:
    if not getattr(sib,'name',None):continue
    classes=sib.get('class') or []
    if any(s in classes for s in ('mm-head','mmm-footer','messages')):break
    if 'poselstvi-mary' in classes or 'poselstvi' in classes:
     txt=normalize_node(sib)
     if txt:segments.append({'kind':'message' if 'poselstvi-mary' in classes else 'context','text':txt})
   message='\n\n'.join(s['text'] for s in segments if s['kind']=='message')
   row={'page':key,'group':current_group,'language':lang,'type':cat,'id':id,'date':date,'source_slug':slug,'source_url':url,'title':title,'text_sha256':sha256(message.encode()).hexdigest(),'segments_count':len(segments)}
   all_rows.append(row)
   grouped[current_group].append(id)
   recorded=archives[lang].get(id)
   if not recorded:violations.append(dict(page=key,error='not_in_language_all',detail=id))
   else:
    for field,val in [('date',date),('title',title),('source_id',slug),('source_url',url),('text',message),('segments',segments)]:
     if recorded[field]!=val: violations.append(dict(page=key,error='mismatch_'+field,detail=id))
   if id not in indexes:violations.append(dict(page=key,error='not_in_union_index',detail=id))
   elif indexes[id]['type']!=cat:violations.append(dict(page=key,error='category_vs_index_type',detail=id))
   if slug[6:7]!='a' if cat=='annual' else slug[6:7]!='s':violations.append(dict(page=key,error='slug_vs_category',detail=id))
  # else skip others
 pageids=[r['id'] for r in all_rows if r['page']==key]
 counts=Counter(pageids)
 for id,cnt in counts.items():
  if cnt!=1:violations.append(dict(page=key,error='duplicate_in_page',detail=f'{id} x{cnt}'))
 expected={id for id,r in archives[lang].items() if r['type']==cat}
 missing=sorted(expected-set(pageids))
 extras=sorted(set(pageids)-expected)
 if missing:violations.append(dict(page=key,error='absent_from_category',detail=','.join(missing)))
 if extras:violations.append(dict(page=key,error='unexpected_from_category',detail=','.join(extras)))
 pagination=[]
 for node in soup.select('a[href]'):
  url=node['href']
  if urlparse(url).path.endswith('/messages/'+cat+'/') and ('page=' in url.lower() or 'start=' in url.lower() or 'offset=' in url.lower()):pagination.append(url)
 for node in soup.select('link[rel="next"],a[rel="next"]'):pagination.append(node.get('href',''))
 by_category[key]={'mhtml_name':name,'mhtml_sha256':sha256(path.read_bytes()).hexdigest(),'mhtml_size':path.stat().st_size,'content_location':origin,'message_count':len(pageids),'json_expected_count':len(expected),'groups':{g:len(ids) for g,ids in grouped.items()},'absent_from_category':missing,'unexpected_from_category':extras,'explicit_pagination_links':sorted(set(pagination))}

# Cross-language group overlap and known language gaps.
group_sets={key: {g:{r['id'] for r in all_rows if r['page']==key and r['group']==g} for g in by_category[key]['groups']} for key in by_category}
cross_language={}
for cat in ('annual','special'):
 eng=set(r['id'] for r in all_rows if r['page']=='en/'+cat)
 cro=set(r['id'] for r in all_rows if r['page']=='hr/'+cat)
 cross_language[cat]={'common':len(eng&cro),'en_only':sorted(eng-cro),'hr_only':sorted(cro-eng)}

result={'method':'read-only independent DOM and JSON cross-check','union_id_count':len(indexes),'total_thematic_entries':len(all_rows),'source_pages':by_category,'cross_language':cross_language,'violations':violations,'violation_count':len(violations),'note':'Category completeness relative to these four saved snapshots and their matching EN/HR /all language files; cannot prove no other pages beyond visible source pagination/links.'}
(OUT/'thematic_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with (OUT/'thematic_entries.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=all_rows[0].keys());w.writeheader();w.writerows(all_rows)
with (OUT/'thematic_violations.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['page','error','detail']);w.writeheader();w.writerows(violations)
print(json.dumps({k:v for k,v in result.items() if k!='violations'},ensure_ascii=False,indent=2))
if violations:
 print('VIOLATIONS',json.dumps(violations,ensure_ascii=False,indent=2)[:8500])
